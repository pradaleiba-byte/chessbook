package com.chessbook

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.chessbook.di.AppContainer
import com.chessbook.ui.repertoire.RepertoireScreen
import com.chessbook.ui.repertoire.RepertoireViewModel
import com.chessbook.ui.theme.ChessbookTheme
import com.chessbook.ui.training.TrainingScreen
import com.chessbook.ui.training.TrainingViewModel

// ─── Application ─────────────────────────────────────────────────────────────

class ChessbookApp : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

// ─── MainActivity ─────────────────────────────────────────────────────────────

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChessbookTheme {
                ChessbookApp()
            }
        }
    }
}

// ─── Navegación raíz (simple, sin NavController) ─────────────────────────────

@Composable
fun ChessbookApp() {
    val context = LocalContext.current
    val app     = context.applicationContext as ChessbookApp

    var activeRepertoireId by remember { mutableStateOf<Long?>(null) }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        if (activeRepertoireId == null) {
            // Pantalla de selección de repertorio
            val repViewModel: RepertoireViewModel = viewModel(
                factory = RepertoireViewModel.Factory(app.container.repository)
            )
            RepertoireScreen(
                viewModel       = repViewModel,
                onStartTraining = { id -> activeRepertoireId = id }
            )
        } else {
            // Pantalla de entrenamiento
            val trainViewModel: TrainingViewModel = viewModel(
                factory = TrainingViewModel.Factory(
                    repository   = app.container.repository,
                    repertoireId = activeRepertoireId!!
                )
            )
            TrainingScreen(viewModel = trainViewModel)
        }
    }
}
