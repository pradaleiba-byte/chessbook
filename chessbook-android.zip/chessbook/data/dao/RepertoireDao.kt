package com.chessbook.data.dao

import androidx.room.*
import com.chessbook.data.entity.Repertoire
import kotlinx.coroutines.flow.Flow

@Dao
interface RepertoireDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(repertoire: Repertoire): Long

    @Update
    suspend fun update(repertoire: Repertoire)

    @Delete
    suspend fun delete(repertoire: Repertoire)

    @Query("SELECT * FROM repertoires ORDER BY lastStudiedAt DESC")
    fun getAllFlow(): Flow<List<Repertoire>>

    @Query("SELECT * FROM repertoires WHERE id = :id")
    suspend fun getById(id: Long): Repertoire?
}
