package com.chessbook.data.dao

import androidx.room.*
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface RepertoireNodeDao {

    // ─── Inserción ──────────────────────────────────────────────────────────

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(node: RepertoireNode): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(nodes: List<RepertoireNode>)

    // ─── Actualización ──────────────────────────────────────────────────────

    @Update
    suspend fun update(node: RepertoireNode)

    // ─── Eliminación ────────────────────────────────────────────────────────

    @Delete
    suspend fun delete(node: RepertoireNode)

    @Query("DELETE FROM repertoire_nodes WHERE repertoireId = :repertoireId")
    suspend fun deleteAllForRepertoire(repertoireId: Long)

    // ─── Consultas de entrenamiento ─────────────────────────────────────────

    /**
     * Obtiene la siguiente jugada vencida para repasar.
     * Prioridad: jugadas más antiguas primero.
     */
    @Query("""
        SELECT * FROM repertoire_nodes
        WHERE repertoireId = :repertoireId
          AND due_date <= :now
        ORDER BY due_date ASC
        LIMIT 1
    """)
    suspend fun getNextDueNode(repertoireId: Long, now: Long = System.currentTimeMillis()): RepertoireNode?

    /**
     * Cuenta cuántas jugadas están vencidas hoy en un repertorio.
     */
    @Query("""
        SELECT COUNT(*) FROM repertoire_nodes
        WHERE repertoireId = :repertoireId
          AND due_date <= :now
    """)
    fun getDueCountFlow(repertoireId: Long, now: Long = System.currentTimeMillis()): Flow<Int>

    /**
     * Jugadas vencidas en todos los repertorios combinados.
     */
    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE due_date <= :now")
    fun getTotalDueCountFlow(now: Long = System.currentTimeMillis()): Flow<Int>

    // ─── Árbol de variantes ─────────────────────────────────────────────────

    /**
     * Obtiene los hijos directos de un nodo (siguientes jugadas posibles).
     */
    @Query("SELECT * FROM repertoire_nodes WHERE parentMoveId = :parentId")
    suspend fun getChildren(parentId: Long): List<RepertoireNode>

    /**
     * Obtiene los nodos raíz de un repertorio (jugadas iniciales).
     */
    @Query("""
        SELECT * FROM repertoire_nodes
        WHERE repertoireId = :repertoireId AND parentMoveId IS NULL
    """)
    suspend fun getRootNodes(repertoireId: Long): List<RepertoireNode>

    /**
     * Todos los nodos de un repertorio como Flow reactivo.
     */
    @Query("SELECT * FROM repertoire_nodes WHERE repertoireId = :repertoireId ORDER BY id ASC")
    fun getAllNodesFlow(repertoireId: Long): Flow<List<RepertoireNode>>

    // ─── Estadísticas ───────────────────────────────────────────────────────

    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE repertoireId = :repertoireId AND status = :status")
    fun getCountByStatus(repertoireId: Long, status: ReviewStatus): Flow<Int>

    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE repertoireId = :repertoireId")
    fun getTotalCount(repertoireId: Long): Flow<Int>
}
