package com.chessbook.data.db

import android.content.Context
import androidx.room.*
import com.chessbook.data.dao.RepertoireDao
import com.chessbook.data.dao.RepertoireNodeDao
import com.chessbook.data.entity.Repertoire
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus

// ─── Convertidores de tipos ──────────────────────────────────────────────────

class Converters {
    @TypeConverter
    fun fromReviewStatus(value: ReviewStatus): String = value.name

    @TypeConverter
    fun toReviewStatus(value: String): ReviewStatus = ReviewStatus.valueOf(value)
}

// ─── Base de datos ───────────────────────────────────────────────────────────

@Database(
    entities = [Repertoire::class, RepertoireNode::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class ChessbookDatabase : RoomDatabase() {

    abstract fun repertoireDao(): RepertoireDao
    abstract fun repertoireNodeDao(): RepertoireNodeDao

    companion object {
        @Volatile
        private var INSTANCE: ChessbookDatabase? = null

        fun getInstance(context: Context): ChessbookDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    ChessbookDatabase::class.java,
                    "chessbook.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
