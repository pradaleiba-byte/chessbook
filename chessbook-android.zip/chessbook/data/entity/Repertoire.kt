package com.chessbook.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PlayerColor { WHITE, BLACK }

@Entity(tableName = "repertoires")
data class Repertoire(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** Nombre del repertorio, ej: "Apertura Inglesa — Blancas" */
    val name: String,

    /** Color con el que juega el usuario */
    val playerColor: PlayerColor,

    /** Timestamp de creación */
    val createdAt: Long = System.currentTimeMillis(),

    /** Timestamp de la última sesión de entrenamiento */
    val lastStudiedAt: Long? = null
)
