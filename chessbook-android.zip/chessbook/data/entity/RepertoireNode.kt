package com.chessbook.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ReviewStatus { NEW, LEARNING, REVIEW, RELEARNING }

@Entity(tableName = "repertoire_nodes")
data class RepertoireNode(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** ID del repertorio al que pertenece esta jugada */
    val repertoireId: Long,

    /** ID de la jugada anterior en el árbol (null = raíz) */
    val parentMoveId: Long? = null,

    /** Posición FEN antes de realizar esta jugada */
    val fen: String,

    /** Jugada en notación SAN, ej: "e4", "Nf3", "O-O" */
    val moveSan: String,

    /** Si es la línea principal o una variante */
    val isMainLine: Boolean = true,

    /** Comentario opcional del entrenador/usuario */
    val comment: String = "",

    // ─── Métricas de Repetición Espaciada (SM-2) ───────────────────────────

    /** Timestamp (ms) de cuándo toca repasar esta jugada */
    @ColumnInfo(name = "due_date")
    val dueDate: Long = System.currentTimeMillis(),

    /** Días hasta el próximo repaso */
    val interval: Int = 0,

    /** Factor de facilidad — nunca baja de 1.3 */
    val easeFactor: Float = 2.5f,

    /** Veces acertadas consecutivamente */
    val repetitions: Int = 0,

    /** Estado actual en el ciclo de aprendizaje */
    val status: ReviewStatus = ReviewStatus.NEW
)
