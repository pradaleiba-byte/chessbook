package com.chessbook.di

import android.content.Context
import com.chessbook.data.db.ChessbookDatabase
import com.chessbook.domain.model.ChessbookRepository

/**
 * Contenedor de dependencias simple (sin Hilt).
 * Para proyectos más grandes, migrar a Hilt o Koin.
 *
 * Uso en tu Activity/Fragment:
 *   val container = (application as ChessbookApp).container
 *   val repository = container.repository
 */
class AppContainer(context: Context) {
    private val database = ChessbookDatabase.getInstance(context)
    val repository = ChessbookRepository(
        repertoireDao = database.repertoireDao(),
        nodeDao       = database.repertoireNodeDao()
    )
}
