package com.chessbook.domain.algorithm

import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus

/**
 * Implementación del algoritmo SM-2 (SuperMemo 2) para repetición espaciada.
 *
 * Calificaciones que recibe el usuario:
 *   0 = Otra vez  → falló, repetir pronto
 *   1 = Difícil   → recordó con mucho esfuerzo
 *   2 = Bien      → recordó con algo de esfuerzo
 *   3 = Fácil     → recordó sin esfuerzo
 */
object SM2Algorithm {

    private const val MIN_EASE_FACTOR = 1.3f
    private const val DEFAULT_EASE_FACTOR = 2.5f

    // Intervalos en minutos para la fase de aprendizaje inicial
    private val LEARNING_INTERVALS_MINUTES = listOf(1, 10)

    /**
     * Calcula el siguiente estado SRS dado el nodo actual y la calificación del usuario.
     *
     * @param node     El nodo actual con sus métricas SRS
     * @param quality  Calificación: 0 (Otra vez), 1 (Difícil), 2 (Bien), 3 (Fácil)
     * @return         Copia del nodo con métricas actualizadas
     */
    fun calculateNextReview(node: RepertoireNode, quality: Int): RepertoireNode {
        require(quality in 0..3) { "La calidad debe estar entre 0 y 3" }

        val now = System.currentTimeMillis()

        return when {
            // ── Falló: reiniciar al ciclo de aprendizaje ──────────────────
            quality == 0 -> {
                node.copy(
                    repetitions = 0,
                    interval    = 0,
                    easeFactor  = (node.easeFactor - 0.2f).coerceAtLeast(MIN_EASE_FACTOR),
                    dueDate     = now + minutesToMs(LEARNING_INTERVALS_MINUTES[0]),
                    status      = ReviewStatus.RELEARNING
                )
            }

            // ── Primera repetición exitosa ─────────────────────────────────
            node.repetitions == 0 -> {
                node.copy(
                    repetitions = 1,
                    interval    = 1,
                    easeFactor  = adjustEase(node.easeFactor, quality),
                    dueDate     = now + daysToMs(1),
                    status      = ReviewStatus.LEARNING
                )
            }

            // ── Segunda repetición exitosa ─────────────────────────────────
            node.repetitions == 1 -> {
                node.copy(
                    repetitions = 2,
                    interval    = 6,
                    easeFactor  = adjustEase(node.easeFactor, quality),
                    dueDate     = now + daysToMs(6),
                    status      = ReviewStatus.LEARNING
                )
            }

            // ── Repeticiones posteriores: usar factor de facilidad ─────────
            else -> {
                val newInterval = when (quality) {
                    1    -> (node.interval * 1.2f).toInt().coerceAtLeast(node.interval + 1) // Difícil
                    3    -> (node.interval * node.easeFactor * 1.3f).toInt()                 // Fácil
                    else -> (node.interval * node.easeFactor).toInt()                        // Bien
                }
                node.copy(
                    repetitions = node.repetitions + 1,
                    interval    = newInterval,
                    easeFactor  = adjustEase(node.easeFactor, quality),
                    dueDate     = now + daysToMs(newInterval),
                    status      = ReviewStatus.REVIEW
                )
            }
        }
    }

    /**
     * Devuelve el intervalo en texto legible para mostrar en los botones SRS.
     */
    fun getIntervalLabel(node: RepertoireNode, quality: Int): String {
        return when {
            quality == 0                -> "< 1 min"
            node.repetitions == 0       -> "1 día"
            node.repetitions == 1       -> "6 días"
            quality == 1                -> "${(node.interval * 1.2f).toInt()} días"
            quality == 3                -> "${(node.interval * node.easeFactor * 1.3f).toInt()} días"
            else                        -> "${(node.interval * node.easeFactor).toInt()} días"
        }
    }

    // ─── Utilidades privadas ─────────────────────────────────────────────────

    private fun adjustEase(current: Float, quality: Int): Float {
        val delta = 0.1f - (3 - quality) * (0.08f + (3 - quality) * 0.02f)
        return (current + delta).coerceAtLeast(MIN_EASE_FACTOR)
    }

    private fun minutesToMs(minutes: Int): Long = minutes * 60 * 1000L
    private fun daysToMs(days: Int): Long = days * 24 * 60 * 60 * 1000L
}
