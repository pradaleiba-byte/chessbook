package com.chessbook.domain.model

import com.chessbook.data.dao.RepertoireDao
import com.chessbook.data.dao.RepertoireNodeDao
import com.chessbook.data.entity.Repertoire
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.domain.algorithm.SM2Algorithm
import kotlinx.coroutines.flow.Flow

class ChessbookRepository(
    private val repertoireDao: RepertoireDao,
    private val nodeDao: RepertoireNodeDao
) {

    // ─── Repertorios ────────────────────────────────────────────────────────

    fun getAllRepertoires(): Flow<List<Repertoire>> =
        repertoireDao.getAllFlow()

    suspend fun createRepertoire(repertoire: Repertoire): Long =
        repertoireDao.insert(repertoire)

    suspend fun deleteRepertoire(repertoire: Repertoire) {
        nodeDao.deleteAllForRepertoire(repertoire.id)
        repertoireDao.delete(repertoire)
    }

    // ─── Importar PGN ───────────────────────────────────────────────────────

    /**
     * Parsea el PGN, inserta todos los nodos en la base de datos y
     * devuelve cuántos nodos se importaron.
     */
    suspend fun importPgn(pgnText: String, repertoireId: Long): Int {
        val nodes = PgnParser.parse(pgnText, repertoireId)
        // Al insertar sin IDs (id=0), Room autogenera los IDs reales
        val nodesWithoutId = nodes.map { it.copy(id = 0) }
        nodeDao.insertAll(nodesWithoutId)
        return nodesWithoutId.size
    }

    // ─── Entrenamiento ──────────────────────────────────────────────────────

    /**
     * Siguiente jugada vencida para repasar.
     */
    suspend fun getNextDueNode(repertoireId: Long): RepertoireNode? =
        nodeDao.getNextDueNode(repertoireId)

    /**
     * Aplica el algoritmo SM-2 y guarda el resultado en la base de datos.
     *
     * @param node    El nodo que acaba de revisar el usuario
     * @param quality 0=Otra vez, 1=Difícil, 2=Bien, 3=Fácil
     */
    suspend fun submitReview(node: RepertoireNode, quality: Int) {
        val updated = SM2Algorithm.calculateNextReview(node, quality)
        nodeDao.update(updated)
    }

    /**
     * Devuelve el texto del intervalo para mostrarlo en los botones SRS.
     */
    fun getIntervalLabel(node: RepertoireNode, quality: Int): String =
        SM2Algorithm.getIntervalLabel(node, quality)

    // ─── Estadísticas ───────────────────────────────────────────────────────

    fun getDueCountFlow(repertoireId: Long): Flow<Int> =
        nodeDao.getDueCountFlow(repertoireId)

    fun getTotalDueCountFlow(): Flow<Int> =
        nodeDao.getTotalDueCountFlow()

    fun getAllNodesFlow(repertoireId: Long): Flow<List<RepertoireNode>> =
        nodeDao.getAllNodesFlow(repertoireId)
}
