package com.chessbook.domain.model

import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.pgn.PgnHolder

/**
 * Parsea un texto PGN y lo convierte en una lista plana de RepertoireNode
 * listos para insertar en Room.
 *
 * Uso:
 *   val nodes = PgnParser.parse(pgnText, repertoireId = 1L)
 */
object PgnParser {

    /**
     * @param pgnText      Texto PGN completo (puede tener múltiples partidas)
     * @param repertoireId ID del repertorio destino
     * @return             Lista de nodos ordenados (raíz primero)
     */
    fun parse(pgnText: String, repertoireId: Long): List<RepertoireNode> {
        val nodes = mutableListOf<RepertoireNode>()

        try {
            val pgn = PgnHolder()
            pgn.loadPgn(pgnText)

            for (game in pgn.games) {
                game.loadMoveText()
                val board = Board()
                var parentId: Long? = null
                var tempId = 1L  // IDs temporales; Room asignará los reales al insertar

                for (move in game.halfMoves) {
                    val fenBefore = board.fen
                    val san = move.san ?: continue

                    // Validar que el movimiento es legal antes de continuar
                    val legalMoves = board.legalMoves()
                    val matchingMove = legalMoves.firstOrNull { it.san == san } ?: continue

                    val node = RepertoireNode(
                        id           = tempId++,
                        repertoireId = repertoireId,
                        parentMoveId = parentId,
                        fen          = fenBefore,
                        moveSan      = san,
                        isMainLine   = true,
                        comment      = move.comment ?: "",
                        dueDate      = System.currentTimeMillis(),
                        status       = ReviewStatus.NEW
                    )

                    nodes.add(node)
                    board.doMove(matchingMove)
                    parentId = node.id
                }
            }
        } catch (e: Exception) {
            throw PgnParseException("Error al parsear el PGN: ${e.message}", e)
        }

        return nodes
    }
}

class PgnParseException(message: String, cause: Throwable? = null) : Exception(message, cause)
