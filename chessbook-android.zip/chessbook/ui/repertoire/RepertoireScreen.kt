package com.chessbook.ui.repertoire

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chessbook.data.entity.Repertoire

// ─── Pantalla de repertorios ─────────────────────────────────────────────────

@Composable
fun RepertoireScreen(
    viewModel: RepertoireViewModel,
    onStartTraining: (Long) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showImportDialog by remember { mutableStateOf(false) }
    var selectedRepertoireId by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Mis repertorios") })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text    = { Text("Nuevo repertorio") },
                icon    = { Icon(Icons.Outlined.Add, contentDescription = null) },
                onClick = { showImportDialog = true }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (val state = uiState) {
                is RepertoireUiState.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is RepertoireUiState.Success -> {
                    if (state.repertoires.isEmpty()) {
                        EmptyRepertoireContent(onImport = { showImportDialog = true })
                    } else {
                        LazyColumn(
                            modifier           = Modifier.fillMaxSize(),
                            contentPadding     = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(state.repertoires, key = { it.id }) { rep ->
                                RepertoireCard(
                                    repertoire      = rep,
                                    onTrain         = { onStartTraining(rep.id) },
                                    onImportPgn     = { selectedRepertoireId = rep.id; showImportDialog = true },
                                    onDelete        = { viewModel.deleteRepertoire(rep) }
                                )
                            }
                        }
                    }
                }
                is RepertoireUiState.Error -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(state.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                else -> Unit
            }
        }
    }

    // Dialog para importar PGN
    if (showImportDialog) {
        ImportPgnDialog(
            onDismiss = { showImportDialog = false },
            onImport  = { pgn ->
                selectedRepertoireId?.let { id ->
                    viewModel.importPgn(pgn, id)
                }
                showImportDialog = false
            }
        )
    }
}

// ─── Tarjeta de repertorio ───────────────────────────────────────────────────

@Composable
private fun RepertoireCard(
    repertoire: Repertoire,
    onTrain: () -> Unit,
    onImportPgn: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier            = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment   = Alignment.CenterVertically
            ) {
                Text(
                    text       = repertoire.name,
                    fontWeight = FontWeight.Medium,
                    fontSize   = 16.sp
                )
                AssistChip(
                    onClick = {},
                    label   = { Text(repertoire.playerColor.name, fontSize = 11.sp) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onTrain, modifier = Modifier.weight(1f)) {
                    Text("Entrenar")
                }
                OutlinedButton(onClick = onImportPgn, modifier = Modifier.weight(1f)) {
                    Text("Importar PGN")
                }
            }
        }
    }
}

// ─── Dialog de importar PGN ──────────────────────────────────────────────────

@Composable
fun ImportPgnDialog(onDismiss: () -> Unit, onImport: (String) -> Unit) {
    var pgnText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Importar PGN") },
        text  = {
            Column {
                Text(
                    text  = "Pega aquí el texto PGN de tu repertorio:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value         = pgnText,
                    onValueChange = { pgnText = it },
                    modifier      = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    placeholder   = { Text("1. e4 e5 2. Nf3 Nc6 ...") },
                    maxLines      = 10
                )
            }
        },
        confirmButton = {
            Button(
                onClick  = { if (pgnText.isNotBlank()) onImport(pgnText) },
                enabled  = pgnText.isNotBlank()
            ) {
                Text("Importar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

// ─── Estado vacío ────────────────────────────────────────────────────────────

@Composable
private fun EmptyRepertoireContent(onImport: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Sin repertorios aún", fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Crea tu primer repertorio e importa\nun PGN para empezar a entrenar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onImport) { Text("Importar PGN") }
        }
    }
}
