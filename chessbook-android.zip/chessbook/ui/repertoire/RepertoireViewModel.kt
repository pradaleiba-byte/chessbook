package com.chessbook.ui.repertoire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.chessbook.data.entity.Repertoire
import com.chessbook.domain.model.ChessbookRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// ─── Estado ──────────────────────────────────────────────────────────────────

sealed interface RepertoireUiState {
    object Loading : RepertoireUiState
    data class Success(val repertoires: List<Repertoire>) : RepertoireUiState
    data class ImportResult(val importedCount: Int) : RepertoireUiState
    data class Error(val message: String) : RepertoireUiState
}

// ─── ViewModel ───────────────────────────────────────────────────────────────

class RepertoireViewModel(
    private val repository: ChessbookRepository
) : ViewModel() {

    val uiState: StateFlow<RepertoireUiState> = repository.getAllRepertoires()
        .map<List<Repertoire>, RepertoireUiState> { RepertoireUiState.Success(it) }
        .catch { emit(RepertoireUiState.Error(it.message ?: "Error desconocido")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RepertoireUiState.Loading)

    /**
     * Importa un PGN dentro del repertorio activo.
     */
    fun importPgn(pgnText: String, repertoireId: Long) {
        viewModelScope.launch {
            try {
                val count = repository.importPgn(pgnText, repertoireId)
                // Aquí podrías emitir un evento one-shot con Channel si lo necesitas
            } catch (e: Exception) {
                // Manejar error de parseo
            }
        }
    }

    fun deleteRepertoire(repertoire: Repertoire) {
        viewModelScope.launch { repository.deleteRepertoire(repertoire) }
    }

    class Factory(private val repository: ChessbookRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            RepertoireViewModel(repository) as T
    }
}
