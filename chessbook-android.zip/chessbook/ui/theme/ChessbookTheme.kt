package com.chessbook.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ─── Paleta de colores ───────────────────────────────────────────────────────

private val chessBrown  = Color(0xFF6B4226)
private val chessGold   = Color(0xFFB58863)
private val chessCream  = Color(0xFFF0D9B5)

private val LightColorScheme = lightColorScheme(
    primary          = chessBrown,
    onPrimary        = Color.White,
    primaryContainer = chessCream,
    onPrimaryContainer = chessBrown,
    secondary        = chessGold,
    onSecondary      = Color.White,
    background       = Color(0xFFFFFBF7),
    surface          = Color(0xFFFFFBF7),
    onBackground     = Color(0xFF1C1B1F),
    onSurface        = Color(0xFF1C1B1F)
)

private val DarkColorScheme = darkColorScheme(
    primary          = chessCream,
    onPrimary        = chessBrown,
    primaryContainer = Color(0xFF4A2D1A),
    onPrimaryContainer = chessCream,
    secondary        = chessGold,
    background       = Color(0xFF1A1410),
    surface          = Color(0xFF1A1410),
    onBackground     = Color(0xFFEDE0D4),
    onSurface        = Color(0xFFEDE0D4)
)

// ─── Tema principal ──────────────────────────────────────────────────────────

@Composable
fun ChessbookTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography  = Typography(),
        content     = content
    )
}
