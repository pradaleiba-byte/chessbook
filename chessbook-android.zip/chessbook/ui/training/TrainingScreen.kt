package com.chessbook.ui.training

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

// ─── Pantalla principal de entrenamiento ─────────────────────────────────────

@Composable
fun TrainingScreen(viewModel: TrainingViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val dueCount by viewModel.dueCount.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header con conteo de jugadas pendientes
        TrainingHeader(dueCount = dueCount)

        Spacer(modifier = Modifier.height(16.dp))

        when (val state = uiState) {
            is TrainingUiState.Loading -> LoadingContent()
            is TrainingUiState.Empty   -> EmptyContent(onBack = { /* navegar atrás */ })
            is TrainingUiState.Error   -> ErrorContent(message = state.message, onRetry = viewModel::loadNextNode)
            is TrainingUiState.Ready   -> ReadyContent(
                state      = state,
                onReveal   = viewModel::revealMove,
                onRate     = viewModel::rate
            )
        }
    }
}

// ─── Header ─────────────────────────────────────────────────────────────────

@Composable
private fun TrainingHeader(dueCount: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Entrenamiento",
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.errorContainer
        ) {
            Text(
                text = "$dueCount pendientes",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}

// ─── Contenido principal ─────────────────────────────────────────────────────

@Composable
private fun ReadyContent(
    state: TrainingUiState.Ready,
    onReveal: () -> Unit,
    onRate: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {

        // Tablero de ajedrez
        ChessboardView(
            fen        = state.node.fen,
            targetMove = if (state.isRevealed) state.node.moveSan else null,
            modifier   = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Info de la posición
        PositionInfoCard(node = state.node, isRevealed = state.isRevealed)

        Spacer(modifier = Modifier.height(16.dp))

        // Botones de acción
        AnimatedVisibility(visible = !state.isRevealed) {
            Button(
                onClick  = onReveal,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ver jugada correcta")
            }
        }

        AnimatedVisibility(visible = state.isRevealed) {
            SrsRatingButtons(
                intervalLabels = state.intervalLabels,
                onRate         = onRate
            )
        }
    }
}

// ─── Tablero de ajedrez ──────────────────────────────────────────────────────

/**
 * Tablero simplificado con Canvas de Compose.
 * Para producción: reemplazar con AndroidView + ChessboardView de una librería.
 */
@Composable
fun ChessboardView(
    fen: String,
    targetMove: String?,
    modifier: Modifier = Modifier
) {
    val lightSquare = Color(0xFFF0D9B5)
    val darkSquare  = Color(0xFFB58863)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
    ) {
        // Grilla 8×8
        Column {
            repeat(8) { row ->
                Row(modifier = Modifier.weight(1f)) {
                    repeat(8) { col ->
                        val isLight = (row + col) % 2 == 0
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(if (isLight) lightSquare else darkSquare),
                            contentAlignment = Alignment.Center
                        ) {
                            // Aquí irían los sprites de las piezas según el FEN
                            // Por ahora mostramos texto de coordenada en debug
                        }
                    }
                }
            }
        }

        // Overlay si hay jugada revelada
        if (targetMove != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text     = targetMove,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color    = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    }
}

// ─── Tarjeta de información de posición ─────────────────────────────────────

@Composable
private fun PositionInfoCard(
    node: com.chessbook.data.entity.RepertoireNode,
    isRevealed: Boolean
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isRevealed) "Jugada correcta: ${node.moveSan}"
                       else "¿Cuál es la mejor jugada?",
                fontWeight = FontWeight.Medium,
                fontSize   = 16.sp
            )
            if (node.comment.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text  = node.comment,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// ─── Botones SRS ─────────────────────────────────────────────────────────────

@Composable
private fun SrsRatingButtons(
    intervalLabels: List<String>,
    onRate: (Int) -> Unit
) {
    val labels   = listOf("Otra vez", "Difícil", "Bien", "Fácil")
    val colors   = listOf(
        Color(0xFFE24B4A), // rojo
        Color(0xFFBA7517), // ámbar
        Color(0xFF378ADD), // azul
        Color(0xFF1D9E75)  // verde
    )

    Column {
        Text(
            text     = "¿Cómo te fue?",
            fontSize = 13.sp,
            color    = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            modifier            = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            labels.forEachIndexed { index, label ->
                OutlinedButton(
                    onClick  = { onRate(index) },
                    modifier = Modifier.weight(1f),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        contentColor = colors[index]
                    ),
                    border   = androidx.compose.foundation.BorderStroke(
                        1.dp, colors[index].copy(alpha = 0.5f)
                    )
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Text(intervalLabels[index], fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// ─── Estados secundarios ─────────────────────────────────────────────────────

@Composable
private fun LoadingContent() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun EmptyContent(onBack: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("¡Todo al día! 🎉", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text      = "No hay jugadas vencidas para hoy.\nVuelve mañana para seguir repasando.",
                textAlign = TextAlign.Center,
                color     = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(onClick = onBack) { Text("Volver al inicio") }
        }
    }
}

@Composable
private fun ErrorContent(message: String, onRetry: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Error", fontSize = 18.sp, color = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.height(8.dp))
            Text(message, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onRetry) { Text("Reintentar") }
        }
    }
}
