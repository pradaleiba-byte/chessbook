package com.chessbook.ui.training

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.domain.algorithm.SM2Algorithm
import com.chessbook.domain.model.ChessbookRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// ─── Estado de la UI ────────────────────────────────────────────────────────

sealed interface TrainingUiState {
    object Loading : TrainingUiState
    object Empty : TrainingUiState          // No hay jugadas vencidas
    data class Ready(
        val node: RepertoireNode,
        val isRevealed: Boolean = false,    // Si se mostró la jugada correcta
        val intervalLabels: List<String>    // Etiquetas para los 4 botones SRS
    ) : TrainingUiState
    data class Error(val message: String) : TrainingUiState
}

// ─── ViewModel ──────────────────────────────────────────────────────────────

class TrainingViewModel(
    private val repository: ChessbookRepository,
    private val repertoireId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow<TrainingUiState>(TrainingUiState.Loading)
    val uiState: StateFlow<TrainingUiState> = _uiState.asStateFlow()

    /** Conteo reactivo de jugadas pendientes hoy */
    val dueCount: StateFlow<Int> = repository
        .getDueCountFlow(repertoireId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init {
        loadNextNode()
    }

    // ─── Cargar siguiente jugada ─────────────────────────────────────────────

    fun loadNextNode() {
        viewModelScope.launch {
            _uiState.value = TrainingUiState.Loading
            try {
                val node = repository.getNextDueNode(repertoireId)
                if (node == null) {
                    _uiState.value = TrainingUiState.Empty
                } else {
                    _uiState.value = TrainingUiState.Ready(
                        node           = node,
                        isRevealed     = false,
                        intervalLabels = buildIntervalLabels(node)
                    )
                }
            } catch (e: Exception) {
                _uiState.value = TrainingUiState.Error("Error al cargar jugada: ${e.message}")
            }
        }
    }

    // ─── Revelar la jugada correcta ──────────────────────────────────────────

    fun revealMove() {
        val current = _uiState.value as? TrainingUiState.Ready ?: return
        _uiState.value = current.copy(isRevealed = true)
    }

    // ─── Calificar la jugada ─────────────────────────────────────────────────

    /**
     * @param quality 0=Otra vez, 1=Difícil, 2=Bien, 3=Fácil
     */
    fun rate(quality: Int) {
        val current = _uiState.value as? TrainingUiState.Ready ?: return
        viewModelScope.launch {
            try {
                repository.submitReview(current.node, quality)
                loadNextNode()
            } catch (e: Exception) {
                _uiState.value = TrainingUiState.Error("Error al guardar calificación: ${e.message}")
            }
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private fun buildIntervalLabels(node: RepertoireNode): List<String> =
        listOf(0, 1, 2, 3).map { SM2Algorithm.getIntervalLabel(node, it) }

    // ─── Factory ─────────────────────────────────────────────────────────────

    class Factory(
        private val repository: ChessbookRepository,
        private val repertoireId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            TrainingViewModel(repository, repertoireId) as T
    }
}
